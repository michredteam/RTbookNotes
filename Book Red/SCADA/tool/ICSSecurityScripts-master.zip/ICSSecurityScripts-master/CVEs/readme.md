# CVE Exploits
On Industrial Security

* CVE-2016-8366-PassRetrieval.py: Phoenix Contact WebVisit Unauthenticated Password Retrieval
* CVE-2016-8380-GetSetHMIValues.py: Phoenix Contact WebVisit Authentication Bypass (Reading & Writing Exported Tags)
* CVE-2017-6026-SessionHijack.py: Schneider Electric M241/M251 Web Interface Session Hijacker
